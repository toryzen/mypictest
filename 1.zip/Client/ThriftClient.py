#!/usr/bin/env python
# encoding: utf-8
import sys, glob

from ThriftInterface import Monitor
from ThriftInterface.ttypes import *

from thrift import Thrift
from thrift.transport import TSocket
from thrift.transport import TTransport
from thrift.protocol  import TBinaryProtocol

class Client(object):
    """Client class"""
    def __init__(self, host, port):
        transport      = TSocket.TSocket(host, port)
        self.transport = TTransport.TBufferedTransport(transport)
        self.protocol  = TBinaryProtocol.TBinaryProtocol(self.transport)
        self.client    = Monitor.Client(self.protocol)
        self.transport.open()

    def sendMessage(self, data):
        '''向服务端发送消息'''
        try:
            data = getCache(data)
            Mess = self.dataHandle(data)
            return self.client.sendMessage(Mess)
        except Thrift.TException, tx:
            #发送失败，本地缓存
            self.setCache(data)
            return tx.message

    def dataHandle(self,data):
        '''消息字典转message对象'''
        Mess = Message()
        for (k,v) in data.iteritems():
            #eval('Mess.%s=%s',(k,v))
            if k=='path':
                Mess.path = '%s' % v
            else if k=='sendtime':
                Mess.sendtime = v
            else if k=='ip':
                Mess.ip = '%s' % v
            else if k=='appid':
                Mess.appid = v
            else if k=='subject':
                Mess.subject = '%s' % v
            else if k=='title':
                Mess.title = '%s' % v
            else if k=='num':
                Mess.num = v
            else if k=='info':
                Mess.info = '%s' % v
            else if k=='testime':
                Mess.testime = v
        return Mess

    def setCache(self,data):
        pass

    def getCache(self,data):
        pass
        return 0

if __name__ == '__main__':
    message          = {}
    message['path']     = '/home/monitor'
    message['sendtime'] = 1234556789
    message['ip']       = '192.168.10.132'
    message['appid']    = 12
    message['subject']  = 'zhuti'
    message['title']    = 'biaoti'
    message['num']      = 22
    message['info']     = 'info'
    message['testime']  = 1234556789

    ClientClass = Client('localhost',9090)
    print ClientClass.sendMessage(message)