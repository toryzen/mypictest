/**
 * The first thing to know about are types. The available types in Thrift are:
 *  bool        Boolean, one byte
 *  byte        Signed byte
 *  i16         Signed 16-bit integer
 *  i32         Signed 32-bit integer
 *  i64         Signed 64-bit integer
 *  double      64-bit floating point value
 *  string      String
 *  binary      Blob (byte array)
 *  map<t1,t2>  Map from one type to another
 *  list<t1>    Ordered list of one type
 *  set<t1>     Set of unique elements of one type
 */
namespace cpp monitor
namespace java monitor
namespace php monitor
namespace py monitor

//消息体
struct Message {
    1: string  path,
    2: i32     sendtime,
    3: string  ip,
    4: i32     appid,
    5: string  subject,
    6: string  title,
    7: i64     num,
    8: string     info,
    9: i32     testime,
    10:i32     receivetime
}

//错误处理
exception InvalidOperation {
    1: i64 num,
    2: string info
}

//定义服务
service Monitor {

    //测试客户端与服务端的正常通信
    void ping(),

    // 客户端发送消息
    void sendMessage(
        1: Message  message
    ) throws (
        1:InvalidOperation ouch
    ),

}