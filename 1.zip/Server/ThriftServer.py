#!/usr/bin/env python
# encoding: utf-8
import sys, glob ,redis ,json

from ThriftInterface import Monitor
from ThriftInterface.ttypes import *

from thrift.transport import TSocket
from thrift.transport import TTransport
from thrift.protocol  import TBinaryProtocol
from thrift.server    import TServer

class MonitorHandler:
    def __init__(self, redishost ,redisport,redisdb):
        self.rediscon = redis.Redis(host=redishost, port=redisport, db=redisdb)

    def sendMessage(self, Mess):
        '''接收客户端消息，写入redis'''
        try:
            message                = {}
            message['path']        = Mess.path
            message['sendtime']    = Mess.sendtime
            message['ip']          = Mess.ip
            message['appid']       = Mess.appid
            message['subject']     = Mess.subject
            message['title']       = Mess.title
            message['num']         = Mess.num
            message['info']        = Mess.info
            message['testime']     = Mess.testime
            message['receivetime'] = 1234556789
            #字典转json 写入redis
            key = '%d:%s:%s' % (Mess.ip,Mess.subject,Mess.title)
            decodejson = json.loads( json.dumps(message) )
            return self.insertRedis(key,decodejson)
        except Exception, e:
            return e.message

    def insertRedis(self, key, message):
        '''写入redis'''
        try:
            return self.rediscon.set(key, message)
        except Exception, e:
            return e

class Servicer(object):
    """Servicer class"""
    def __init__(self, Handlers, serverport):
        self.processor = Monitor.Processor(Handlers)
        self.transport = TSocket.TServerSocket(port = serverport)
        self.tfactory  = TTransport.TBufferedTransportFactory()
        self.pfactory  = TBinaryProtocol.TBinaryProtocolFactory()
        
    def run(self):
        #self.server = TServer.TThreadedServer(self.processor, self.transport, self.tfactory, self.pfactory)
        self.server = TServer.TThreadPoolServer(self.processor, self.transport, self.tfactory, self.pfactory)
        self.server.serve()

if __name__ == '__main__':
    Handler = MonitorHandler('localhost',6379,0)
    server = Servicer(Handler, 9090)
    server.run()

